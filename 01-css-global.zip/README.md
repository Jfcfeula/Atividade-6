# 01 - CSS Global

Projeto Vite (React) - versão **01 - CSS Global**.

Instruções rápidas:

```bash
npm install
npm run dev
```

Requirements: node >= 16, npm/yarn.

