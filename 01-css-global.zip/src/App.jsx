import React, {useEffect, useState} from 'react'
import Navbar from './components/Navbar'
import ProductCard from './components/ProductCard'
import Skeleton from './components/Skeleton'
import {PRODUCTS} from './data/products'
import './styles/global.css'

export default function App(){
  const [loading,setLoading]=useState(true)
  const [cart,setCart]=useState([])

  useEffect(()=>{const t=setTimeout(()=>setLoading(false),900);return ()=>clearTimeout(t)},[])

  function add(p){ setCart(c=>[...c,p.id]) }

  return (
    <div>
      <Navbar cartCount={cart.length} />
      <main className='app-shell'>
        <div className='container'>
          <section className='grid' aria-live='polite'>
            {loading ? Array.from({length:6}).map((_,i)=>(<Skeleton key={i}/>)) : PRODUCTS.map(p=>(<ProductCard key={p.id} product={p} onAdd={add}/>))}
          </section>
        </div>
      </main>
    </div>
  )
}
