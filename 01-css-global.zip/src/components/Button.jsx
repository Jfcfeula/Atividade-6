import React from 'react'

export default function Button({variant='solid', children, disabled, loading, ...rest}){
  return (
    <button className={`button ${variant}`} aria-pressed={variant==='ghost' ? 'false': undefined} disabled={disabled||loading} {...rest}>
      {loading ? 'Carregando...' : children}
    </button>
  )
}
