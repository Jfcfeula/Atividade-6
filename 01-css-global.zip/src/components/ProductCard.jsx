import React from 'react'
import Button from './Button'

export default function ProductCard({product,onAdd}){
  return (
    <article className='card' tabIndex={0} aria-labelledby={`title-${product.id}`}>
      <img className='media' src={product.image} alt={product.title} loading='lazy' />
      <div className='body'>
        <div style={{display:'flex',justifyContent:'space-between',alignItems:'center'}}>
          <span className='tag' aria-hidden>{product.tag}</span>
          <span className='rating' aria-label={`${product.rating} estrelas`}>★ {product.rating.toFixed(1)}</span>
        </div>
        <h3 id={`title-${product.id}`} className='title'>{product.title}</h3>
        <div className='price'>R$ {product.price.toFixed(2)}</div>
        <div style={{marginTop:10}}>
          <Button variant='solid' onClick={()=>onAdd(product)}>Adicionar</Button>
        </div>
      </div>
    </article>
  )
}
