import React from 'react'

export default function Skeleton(){
  return (
    <div className='card' aria-hidden>
      <div className='media skeleton' style={{height:0,paddingBottom:'100%'}} />
      <div className='body'>
        <div style={{height:18,width:'60%'}} className='skeleton' />
        <div style={{height:14,width:'40%',marginTop:8}} className='skeleton' />
      </div>
    </div>
  )
}
