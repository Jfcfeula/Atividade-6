# 02 - CSS Modules

Projeto Vite (React) - versão **02 - CSS Modules**.

Instruções rápidas:

```bash
npm install
npm run dev
```

Requirements: node >= 16, npm/yarn.

