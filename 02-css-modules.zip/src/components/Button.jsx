import React from 'react'
import styles from './Button.module.css'
export default function Button({variant='solid', children, disabled, loading, ...rest}){
  return <button className={[styles.button, styles[variant]].join(' ')} disabled={disabled||loading} {...rest}>{loading? 'Carregando...' : children}</button>
}