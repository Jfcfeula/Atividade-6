import React, {useEffect, useState} from 'react'
import styles from './Navbar.module.css'

export default function Navbar({cartCount=0}){
  const [theme,setTheme]=useState(()=>localStorage.getItem('app-theme')||'light')
  useEffect(()=>{document.documentElement.setAttribute('data-theme',theme);localStorage.setItem('app-theme',theme)},[theme])
  return (
    <nav className={styles.navbar} role='navigation' aria-label='main navigation'>
      <div className={styles.logo}>Loja</div>
      <div style={{display:'flex',gap:12,alignItems:'center'}}>
        <button className={styles.themeToggle} onClick={()=>setTheme(t=>t==='light'?'dark':'light')} aria-label='Alternar tema'>{theme==='light'?'🌞':'🌙'}</button>
        <div aria-hidden style={{position:'relative'}}>
          <button className='button ghost' aria-label='Ver carrinho'>🛒</button>
          {cartCount>0 && <span style={{position:'absolute',right:-6,top:-6,minWidth:20,height:20,borderRadius:10,background:'red',color:'white',display:'flex',alignItems:'center',justifyContent:'center',fontSize:12}} aria-hidden>{cartCount}</span>}
        </div>
      </div>
    </nav>
  )
}