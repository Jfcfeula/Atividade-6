import React from 'react'
import styles from './ProductCard.module.css'
import Button from './Button'

export default function ProductCard({product,onAdd}){
  return (
    <article className={styles.card} tabIndex={0} aria-labelledby={`title-${product.id}`}>
      <img className={styles.media} src={product.image} alt={product.title} loading='lazy' />
      <div className={styles.body}>
        <div style={{display:'flex',justifyContent:'space-between',alignItems:'center'}}>
          <span className={styles.tag} aria-hidden>{product.tag}</span>
          <span className={styles.rating} aria-label={`${product.rating} estrelas`}>★ {product.rating.toFixed(1)}</span>
        </div>
        <h3 id={`title-${product.id}`} className={styles.title}>{product.title}</h3>
        <div className={styles.price}>R$ {product.price.toFixed(2)}</div>
        <div style={{marginTop:10}}>
          <Button variant='solid' onClick={()=>onAdd(product)}>Adicionar</Button>
        </div>
      </div>
    </article>
  )
}