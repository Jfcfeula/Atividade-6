export const PRODUCTS = [
  { id: 'p1', title: 'Tênis de corrida leve e respirável com amortecimento avançado', price: 299.9, rating: 4.7, tag: 'Novo', image: 'https://via.placeholder.com/600' },
  { id: 'p2', title: 'Mochila urbana com compartimento para laptop 15\"', price: 199.5, rating: 4.3, tag: 'Promo', image: 'https://via.placeholder.com/600' },
  { id: 'p3', title: 'Fones sem fio com redução de ruído e 30h de bateria', price: 499.0, rating: 4.9, tag: 'Novo', image: 'https://via.placeholder.com/600' },
  { id: 'p4', title: 'Relógio esportivo GPS com monitor cardíaco', price: 749.0, rating: 4.4, tag: 'Promo', image: 'https://via.placeholder.com/600' },
  { id: 'p5', title: 'Câmera de ação 4K com estabilização eletrônica', price: 899.0, rating: 4.1, tag: 'Novo', image: 'https://via.placeholder.com/600' },
  { id: 'p6', title: 'Suplemento vitamínico diário 120 cápsulas', price: 59.9, rating: 3.9, tag: 'Promo', image: 'https://via.placeholder.com/600' }
]
