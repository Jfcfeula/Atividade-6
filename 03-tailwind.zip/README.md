# 03 - Tailwind CSS

Projeto Vite (React) - versão **03 - Tailwind CSS**.

Instruções rápidas:

```bash
npm install
npm run dev
```

Requirements: node >= 16, npm/yarn.

