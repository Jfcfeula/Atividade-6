import React, {useState,useEffect} from 'react'
import {PRODUCTS} from './data/products'
import Navbar from './components/Navbar'
import ProductCard from './components/ProductCard'
import Skeleton from './components/Skeleton'
import './styles/index.css'

export default function App(){
  const [loading,setLoading]=useState(true); const [cart,setCart]=useState([])
  useEffect(()=>{const t=setTimeout(()=>setLoading(false),900);return ()=>clearTimeout(t)},[])
  function add(p){ setCart(c=>[...c,p.id]) }
  return (
    <div>
      <Navbar cartCount={cart.length} />
      <main className='pt-18 min-h-screen'>
        <div className='max-w-6xl mx-auto px-5 py-6'>
          <section className='grid gap-4 grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4' aria-live='polite'>
            {loading? Array.from({length:6}).map((_,i)=>(<Skeleton key={i}/>)) : PRODUCTS.map(p=>(<ProductCard key={p.id} product={p} onAdd={add}/>))}
          </section>
        </div>
      </main>
    </div>
  )
}