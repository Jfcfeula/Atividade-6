import React, {useEffect, useState} from 'react'
export default function Navbar({cartCount=0}){
  const [theme,setTheme]=useState(()=>localStorage.getItem('app-theme')||'light')
  useEffect(()=>{ if(theme==='dark'){document.documentElement.classList.add('dark')} else {document.documentElement.classList.remove('dark')} localStorage.setItem('app-theme',theme)},[theme])
  return (
    <nav className='fixed inset-x-0 top-0 h-18 flex items-center justify-between px-5 bg-white/90 dark:bg-slate-900/90 backdrop-blur-sm shadow-sm'>
      <div className='font-bold'>Loja</div>
      <div className='flex items-center gap-3'>
        <button onClick={()=>setTheme(t=>t==='light'?'dark':'light')} aria-label='Alternar tema' className='p-2 rounded-md'>{theme==='light'? '🌞':'🌙'}</button>
        <div className='relative'>
          <button aria-label='Ver carrinho' className='p-2 rounded-md'>🛒</button>
          {cartCount>0 && <span className='absolute -right-2 -top-2 min-w-[20px] h-[20px] rounded-full bg-red-600 text-white flex items-center justify-center text-xs'>{cartCount}</span>}
        </div>
      </div>
    </nav>
  )
}