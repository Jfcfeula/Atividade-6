import React from 'react'
import Button from './Button'
export default function ProductCard({product,onAdd}){
  return (
    <article tabIndex={0} aria-labelledby={`title-${product.id}`} className='bg-white dark:bg-slate-800 border border-gray-100 dark:border-slate-700 rounded-xl overflow-hidden transform transition duration-180 hover:-translate-y-2 focus-visible:ring-4 focus-visible:ring-primary/20'>
      <img src={product.image} alt={product.title} loading='lazy' className='w-full aspect-square object-cover' />
      <div className='p-3'>
        <div className='flex justify-between items-center'>
          <span className='text-xs px-2 py-1 rounded-full bg-gray-100 dark:bg-slate-700'>{product.tag}</span>
          <span className='text-sm'>★ {product.rating.toFixed(1)}</span>
        </div>
        <h3 id={`title-${product.id}`} className='mt-2 text-sm leading-5 line-clamp-2'>{product.title}</h3>
        <div className='font-semibold mt-2'>R$ {product.price.toFixed(2)}</div>
        <div className='mt-3'>
          <Button variant='solid' onClick={()=>onAdd(product)}>Adicionar</Button>
        </div>
      </div>
    </article>
  )
}