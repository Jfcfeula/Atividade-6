# 04 - styled-components

Projeto Vite (React) - versão **04 - styled-components**.

Instruções rápidas:

```bash
npm install
npm run dev
```

Requirements: node >= 16, npm/yarn.

