import React, {useEffect, useState} from 'react'
import { ThemeProvider } from 'styled-components'
import { lightTheme, darkTheme } from './theme'
import Navbar from './components/Navbar'
import ProductCard from './components/ProductCard'
import Skeleton from './components/Skeleton'
import {PRODUCTS} from './data/products'

export default function App(){
  const [loading,setLoading]=useState(true)
  const [cart,setCart]=useState([])
  const [themeName,setThemeName]=useState(()=>localStorage.getItem('app-theme')||'light')
  useEffect(()=>{const t=setTimeout(()=>setLoading(false),900);return ()=>clearTimeout(t)},[])
  useEffect(()=>{localStorage.setItem('app-theme',themeName)},[themeName])
  function add(p){ setCart(c=>[...c,p.id]) }
  return (
    <ThemeProvider theme={themeName==='light'? lightTheme : darkTheme}>
      <div>
        <Navbar cartCount={cart.length} themeName={themeName} setThemeName={setThemeName} />
        <main style={{paddingTop:72,minHeight:'100vh'}}>
          <div style={{maxWidth:1200,margin:'0 auto',padding:20}}>
            <section style={{display:'grid',gap:16,gridTemplateColumns:'repeat(4,1fr)'}} aria-live='polite'>
              {loading? Array.from({length:6}).map((_,i)=>(<Skeleton key={i}/>)) : PRODUCTS.map(p=>(<ProductCard key={p.id} product={p} onAdd={add}/>))}
            </section>
          </div>
        </main>
      </div>
    </ThemeProvider>
  )
}