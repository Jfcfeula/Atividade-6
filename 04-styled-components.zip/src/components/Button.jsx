import styled from 'styled-components'
import React from 'react'
const Btn = styled.button`
  display:inline-flex;align-items:center;justify-content:center;gap:8px;padding:8px 12px;border-radius:10px;border:1px solid transparent;cursor:pointer;transition:transform .18s,opacity .18s;
  background:${p=> p.variant==='solid' ? p.theme.primary : 'transparent'}; color:${p=> p.variant==='solid' ? '#fff' : p.theme.primary};
`
export default function Button({variant='solid',children,loading,disabled,...rest}){ return <Btn variant={variant} disabled={disabled||loading} {...rest}>{loading? 'Carregando...' : children}</Btn> }