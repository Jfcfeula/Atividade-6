import React from 'react'
import styled from 'styled-components'

const Nav = styled.nav`position:fixed;left:0;right:0;top:0;height:72px;display:flex;align-items:center;justify-content:space-between;padding:0 20px;background:rgba(255,255,255,0.9);backdrop-filter:blur(6px);box-shadow:0 1px 2px rgba(0,0,0,0.06);`

export default function Navbar({cartCount=0, themeName, setThemeName}){
  return (
    <Nav role='navigation' aria-label='main navigation' style={{background: 'rgba(0,0,0,0.03)'}}>
      <div style={{fontWeight:700}}>Loja</div>
      <div style={{display:'flex',gap:12,alignItems:'center'}}>
        <button onClick={()=>setThemeName(t=>t==='light'?'dark':'light')} aria-label='Alternar tema'>{themeName==='light'?'🌞':'🌙'}</button>
        <div style={{position:'relative'}}>
          <button aria-label='Ver carrinho'>🛒</button>
          {cartCount>0 && <span style={{position:'absolute',right:-6,top:-6,minWidth:20,height:20,borderRadius:10,background:'red',color:'white',display:'flex',alignItems:'center',justifyContent:'center',fontSize:12}}>{cartCount}</span>}
        </div>
      </div>
    </Nav>
  )
}