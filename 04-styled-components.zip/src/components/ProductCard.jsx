import React from 'react'
import styled from 'styled-components'
import Button from './Button'

const Card = styled.article`
  background:${p=>p.theme.bg}; color:${p=>p.theme.text}; border-radius:${p=>p.theme.radius}; overflow:hidden; border:1px solid rgba(0,0,0,0.06); transition:transform .18s,box-shadow .18s;
  &:hover{ transform:translateY(-6px); box-shadow:${p=>p.theme.shadow} }
`
const Img = styled.img`width:100%; aspect-ratio:1/1; object-fit:cover; display:block`
const Body = styled.div`padding:12px`
const Title = styled.h3`line-height:1.15; height:3em; overflow:hidden; display:-webkit-box; -webkit-line-clamp:2; -webkit-box-orient:vertical`

export default function ProductCard({product,onAdd}){
  return (
    <Card tabIndex={0} aria-labelledby={`title-${product.id}`}>
      <Img src={product.image} alt={product.title} loading='lazy' />
      <Body>
        <div style={{display:'flex',justifyContent:'space-between',alignItems:'center'}}>
          <span style={{padding:'2px 8px',borderRadius:999,fontSize:12,background:'rgba(0,0,0,0.05)'}}>{product.tag}</span>
          <span>★ {product.rating.toFixed(1)}</span>
        </div>
        <Title id={`title-${product.id}`}>{product.title}</Title>
        <div style={{fontWeight:700,marginTop:8}}>R$ {product.price.toFixed(2)}</div>
        <div style={{marginTop:10}}><Button variant='solid' onClick={()=>onAdd(product)}>Adicionar</Button></div>
      </Body>
    </Card>
  )
}