import React from 'react'
import styled from 'styled-components'
const Card = styled.div`border-radius:12px;overflow:hidden;border:1px solid rgba(0,0,0,0.06)`
const Media = styled.div`width:100%;padding-bottom:100%;background:linear-gradient(90deg,#f3f3f3 25%,#ececec 37%,#f3f3f3 63%);background-size:400% 100%;animation:shimmer 1.2s linear infinite`
const Body = styled.div`padding:12px`
export default function Skeleton(){ return (<Card aria-hidden><Media/><Body><div style={{height:18,width:'60%',background:'#eee'}}></div><div style={{height:14,width:'40%',marginTop:8,background:'#eee'}}></div></Body></Card>) }